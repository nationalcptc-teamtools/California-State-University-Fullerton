
.. _sunos:

***********************
SunOS Specific Services
***********************

The modules described in this chapter provide interfaces to features that are
unique to SunOS 5 (also known as Solaris version 2).


.. toctree::

   sunaudio.rst
